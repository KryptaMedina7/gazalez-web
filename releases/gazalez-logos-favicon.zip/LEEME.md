# Logos y favicon de Gazalez

- logos/gazalez-logo.png: logo principal original utilizado en el sitio.
- logos/gazalez-holding-group.svg: composicion de Gazalez Holding Group utilizada en el sitio. Incluye imagen y tipografia incrustadas; no requiere archivos externos. El simbolo incrustado es raster, no un trazado vectorial.
- favicon/favicon.png: copia exacta del logo principal, que es la imagen utilizada actualmente como favicon. No es un ICO ni una version reducida.

El archivo antiguo gazal-logo.png es identico a gazalez-logo.png y se omite para evitar duplicados y mantener el nombre Gazalez.

## Incorporacion al ZIP de PHP

Los dos logos ya forman parte de public_html/assets/ en el paquete del sitio.
Si prefieres un nombre dedicado para el favicon, copia favicon/favicon.png a public_html/assets/favicon.png y cambia el enlace de icono en gazalez-private/views/layout.php a:

<link rel="icon" type="image/png" href="<?= e(local_url('/assets/favicon.png')) ?>">

Tambien puedes mantener la configuracion actual, que apunta a /assets/gazalez-logo.png.
Este paquete complementario no reemplaza los archivos PHP ni cambia las animaciones.
SHA256.json permite comprobar que los archivos originales se conservaron intactos.
